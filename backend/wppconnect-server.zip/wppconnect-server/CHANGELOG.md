## 2.8.6 (2025-03-29)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.36.4 ([#2144](https://github.com/wppconnect-team/wppconnect-server/issues/2144)) ([8087d8b](https://github.com/wppconnect-team/wppconnect-server/commit/8087d8b136c7ad7ec11df59a10105fd98a7e4286))

## 2.8.5 (2025-03-27)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.36.3 ([#2141](https://github.com/wppconnect-team/wppconnect-server/issues/2141)) ([2a31476](https://github.com/wppconnect-team/wppconnect-server/commit/2a314760f452fdadc0331a7dd62a7304e4f4cb9b))

## 2.8.4 (2025-03-26)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.36.2 ([#2139](https://github.com/wppconnect-team/wppconnect-server/issues/2139)) ([828dcd0](https://github.com/wppconnect-team/wppconnect-server/commit/828dcd015ab4b4ac89bd9c0877fae94a5489f8e3))

## 2.8.3 (2025-01-09)

## 2.8.2 (2024-12-23)

## 2.8.1 (2024-10-30)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.35.1 ([#2063](https://github.com/wppconnect-team/wppconnect-server/issues/2063)) ([34d88d6](https://github.com/wppconnect-team/wppconnect-server/commit/34d88d6bf41efda995de33c59c0039ef8223590b))

# 2.8.0 (2024-10-29)

# 2.7.0 (2024-09-09)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.34.0 ([#2015](https://github.com/wppconnect-team/wppconnect-server/issues/2015)) ([7bedd09](https://github.com/wppconnect-team/wppconnect-server/commit/7bedd09bd1a1575964311c989e3377bc6e737704))

# 2.6.0 (2024-08-05)

## 2.5.2 (2024-06-24)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.32.3 ([#1926](https://github.com/wppconnect-team/wppconnect-server/issues/1926)) ([5c596b4](https://github.com/wppconnect-team/wppconnect-server/commit/5c596b4e5b8ec3549c6e378f01acb6af3606a524))

## 2.5.1 (2024-06-18)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.32.2 ([#1915](https://github.com/wppconnect-team/wppconnect-server/issues/1915)) ([5cb0b0e](https://github.com/wppconnect-team/wppconnect-server/commit/5cb0b0e59667e11cec32e4761dec66ffee2cd6c9))

# 2.5.0 (2024-06-13)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.32.0 ([#1901](https://github.com/wppconnect-team/wppconnect-server/issues/1901)) ([765810d](https://github.com/wppconnect-team/wppconnect-server/commit/765810dde565d79c1b1c1aa7571010a79b054edd))

## 2.4.6 (2024-06-12)

## 2.4.5 (2024-06-11)

## 2.4.4 (2024-05-04)

## 2.4.3 (2024-04-25)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.30.2 ([#1826](https://github.com/wppconnect-team/wppconnect-server/issues/1826)) ([6fed8ae](https://github.com/wppconnect-team/wppconnect-server/commit/6fed8aeb2f09ca62e151f7bc8e65c5950dbfcf64))

## 2.4.2 (2024-03-28)

### Bug Fixes

- Fixed DockerFile ([fed13ec](https://github.com/wppconnect-team/wppconnect-server/commit/fed13ece778462fa540bcfa55823863c7fe1bba0))

## 2.4.1 (2024-03-12)

# 2.4.0 (2024-01-26)

### Bug Fixes

- Replaced ts-node with tsx ([66ae213](https://github.com/wppconnect-team/wppconnect-server/commit/66ae213adab5cc6aeeab77e6ee422e2ad9ee0c22))

# 2.3.0 (2023-11-15)

## 2.2.5 (2023-08-27)

## 2.2.4 (2023-06-05)

## 2.2.3 (2023-06-05)

### Bug Fixes

- Removed clearsession on route 'close-session' ([1df6154](https://github.com/wppconnect-team/wppconnect-server/commit/1df6154143bb17cff38d92daddfa9cfb5f8fba0d))

## 2.2.2 (2023-06-04)

### Bug Fixes

- Upgrade @wppconnect-team/wppconnect@1.27.1 ([81feb71](https://github.com/wppconnect-team/wppconnect-server/commit/81feb714598b7bb03689489f9d5dad7989b1ddab))

## 2.2.1 (2023-06-02)

# 2.2.0 (2023-06-02)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.27.0 ([#1273](https://github.com/wppconnect-team/wppconnect-server/issues/1273)) ([1047dff](https://github.com/wppconnect-team/wppconnect-server/commit/1047dffab930686b5cc1f1adf9f854033f48e080))

## 2.1.2 (2023-06-01)

## 2.1.1 (2023-06-01)

# 2.1.0 (2023-06-01)

## 2.0.1 (2023-04-14)

# 2.0.0 (2023-04-03)

### Bug Fixes

- Fixed warning for aws-s3 ([d4d4b86](https://github.com/wppconnect-team/wppconnect-server/commit/d4d4b86331494f8514a87b41b76740070b9682a0))

## 1.8.5 (2023-03-13)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.23.0 ([b61c75c](https://github.com/wppconnect-team/wppconnect-server/commit/b61c75ca4bda30288fe1833424f1ff52d65ae1da))

## 1.8.4 (2023-02-19)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.22.0 ([#1104](https://github.com/wppconnect-team/wppconnect-server/issues/1104)) ([b444adb](https://github.com/wppconnect-team/wppconnect-server/commit/b444adbe9b5e135ba327e4f7cce6b8b623deedde))

## 1.8.3 (2023-02-03)

## 1.8.2 (2023-01-13)

### Bug Fixes

- Fixed send message to groups (close [#1049](https://github.com/wppconnect-team/wppconnect-server/issues/1049)) ([f8bc6e4](https://github.com/wppconnect-team/wppconnect-server/commit/f8bc6e4ee14b36e266b86bcf9998acf96629019f))

## 1.8.1 (2022-12-28)

# 1.8.0 (2022-12-15)

## 1.7.4 (2022-12-12)

### Bug Fixes

- Fixed return undefined on sendListMsg ([eb830ce](https://github.com/wppconnect-team/wppconnect-server/commit/eb830cee97384a0c9a84db8abc0d5f75ea688c86))

## 1.7.3 (2022-12-03)

## 1.7.2 (2022-11-18)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.19.1 ([#988](https://github.com/wppconnect-team/wppconnect-server/issues/988)) ([1c391e0](https://github.com/wppconnect-team/wppconnect-server/commit/1c391e00e65e70356de26b286e423a649f0ef7af))

## 1.7.1 (2022-11-02)

# 1.7.0 (2022-11-02)

## 1.6.4 (2022-10-20)

## 1.6.3 (2022-10-10)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.17.1 ([#931](https://github.com/wppconnect-team/wppconnect-server/issues/931)) ([04326bf](https://github.com/wppconnect-team/wppconnect-server/commit/04326bf1a142d07d8ca63a807211b407023898d1))

## 1.6.2 (2022-08-09)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.16.1 ([#866](https://github.com/wppconnect-team/wppconnect-server/issues/866)) ([a824339](https://github.com/wppconnect-team/wppconnect-server/commit/a8243392f8daadef5dec2205263d5a44840ae4ef))

## 1.6.1 (2022-08-05)

### Bug Fixes

- **deps:** update dependency @wppconnect-team/wppconnect to ^1.16.0 ([#860](https://github.com/wppconnect-team/wppconnect-server/issues/860)) ([5f72973](https://github.com/wppconnect-team/wppconnect-server/commit/5f72973788d2844d2297acd73b96e76001b70c37))

# 1.6.0 (2022-07-20)

# 1.5.0 (2022-07-12)

### Features

- Delete all chats close [#483](https://github.com/wppconnect-team/wppconnect-server/issues/483) ([f47a253](https://github.com/wppconnect-team/wppconnect-server/commit/f47a253b1024778f9c3ed5d14a638689be464936))

# 1.4.0 (2022-06-29)

## 1.3.4 (2022-06-20)

## 1.3.3 (2022-06-01)

## 1.3.2 (2022-05-31)

## 1.3.1 (2022-05-10)

# 1.3.0 (2022-05-10)

### Features

- Updated all packages ([5e7b9f2](https://github.com/wppconnect-team/wppconnect-server/commit/5e7b9f2240ccc0e44a129296e92dd6fb5393380e))

# 1.2.0 (2022-04-25)

## 1.1.23 (2022-03-13)

## 1.1.22 (2022-03-07)

## 1.1.21 (2022-02-24)

## 1.1.20 (2022-01-23)

## 1.1.19 (2022-01-21)

## 1.1.18 (2022-01-17)

## 1.1.17 (2022-01-16)

## 1.1.16 (2022-01-14)

## 1.1.15 (2022-01-09)

## 1.1.14 (2021-12-21)

## 1.1.13 (2021-12-09)

## 1.1.12 (2021-12-09)

## 1.1.11 (2021-11-16)

## 1.1.10 (2021-11-12)

## 1.1.9 (2021-11-08)

## 1.1.8 (2021-11-08)

## 1.1.7 (2021-10-21)

## 1.1.6 (2021-10-13)

### Bug Fixes

- block/unblock contato. ([9401b16](https://github.com/wppconnect-team/wppconnect-server/commit/9401b168ce08eb62c5ea392db82df34b69753775))

## 1.1.5 (2021-10-01)

## 1.1.4 (2021-09-22)

## 1.1.3 (2021-08-13)

## 1.1.2 (2021-08-11)

## 1.1.1 (2021-08-06)

# 1.1.0 (2021-08-04)

## 1.0.3 (2021-07-15)

## 1.0.2 (2021-07-14)

## [1.0.1](https://github.com/wppconnect-team/wppconnect-server/compare/v1.0.0...v1.0.1) (2021-06-13)

### Bug Fixes

- Archive only unarchived chats ([#37](https://github.com/wppconnect-team/wppconnect-server/issues/37)) ([5985296](https://github.com/wppconnect-team/wppconnect-server/commit/5985296d97a9ccb19625e7ddbc07ecacc0ce65c6))
- Corrigido a entrada principal de arquivo JS ([f513c64](https://github.com/wppconnect-team/wppconnect-server/commit/f513c64247fe01e9297df27036ad1141278e87c2))
