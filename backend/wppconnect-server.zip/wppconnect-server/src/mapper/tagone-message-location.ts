export default {
  loc: 'loc',
  lat: 'lat',
  lng: 'lng',
};
